import React from 'react';
import { Link } from 'react-router-dom';
import { Flame, MapPin, Phone, Mail, Clock } from 'lucide-react';

const Footer: React.FC = () => {
  const handleWhatsApp = () => {
    const message = 'Olá! Gostaria de mais informações sobre as churrasqueiras da Personal Grill.';
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e Descrição */}
          <div className="col-span-1 md:col-span-2">
            <img
              src="https://i.imgur.com/JSQwSQi.png"
              alt="Personal Grill"
              className="h-16 w-auto mb-4"
            />
            <p className="text-gray-300 mb-6 max-w-md">
              Churrasqueiras premium sob medida em Belém. Tecnologia, design e mini-curso de churrasco incluso. 
              Estrutura em aço inox 304 para alta durabilidade.
            </p>
            <button
              onClick={handleWhatsApp}
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-medium transition-colors inline-flex items-center"
            >
              <Phone size={18} className="mr-2" />
              (91) 99358-9908
            </button>
          </div>

          {/* Institucional */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-orange-500">Institucional</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition-colors">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/sobre" className="text-gray-300 hover:text-white transition-colors">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className="text-gray-300 hover:text-white transition-colors">
                  Portfólio
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-300 hover:text-white transition-colors">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          {/* Serviços */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-orange-500">Serviços</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/servicos" className="text-gray-300 hover:text-white transition-colors">
                  Churrasqueiras
                </Link>
              </li>
              <li>
                <Link to="/servicos" className="text-gray-300 hover:text-white transition-colors">
                  Acessórios
                </Link>
              </li>
              <li>
                <Link to="/servicos" className="text-gray-300 hover:text-white transition-colors">
                  Projeto 3D
                </Link>
              </li>
              <li>
                <Link to="/servicos" className="text-gray-300 hover:text-white transition-colors">
                  Mini-curso
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Informações de Contato */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center">
              <MapPin className="text-orange-500 mr-3" size={20} />
              <div>
                <p className="font-medium">Localização</p>
                <p className="text-gray-300 text-sm">Belém e região metropolitana</p>
              </div>
            </div>
            <div className="flex items-center">
              <Phone className="text-orange-500 mr-3" size={20} />
              <div>
                <p className="font-medium">WhatsApp</p>
                <p className="text-gray-300 text-sm">(91) 99358-9908</p>
              </div>
            </div>
            <div className="flex items-center">
              <Clock className="text-orange-500 mr-3" size={20} />
              <div>
                <p className="font-medium">Atendimento</p>
                <p className="text-gray-300 text-sm">Seg - Sex: 8h às 18h</p>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 Personal Grill. Todos os direitos reservados. 
            <span className="text-orange-500 ml-2">Churrasqueiras Premium em Belém</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;