import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ExternalLink } from 'lucide-react';

const PortfolioPreview: React.FC = () => {
  const projects = [
    {
      id: 1,
      image: 'https://i.imgur.com/nDNKpqC.jpeg',
      title: 'Churrasqueira Premium Inox',
      location: 'Belém - PA',
      description: 'Modelo executivo com acabamento em granito preto e sistema rotativo de 4 espetos'
    },
    {
      id: 2,
      image: 'https://i.imgur.com/sYCegxl.jpeg',
      title: 'Alvenaria Rústica Premium',
      location: 'Ananindeua - PA',
      description: 'Construção em alvenaria com revestimento em pedra natural e forno integrado'
    },
    {
      id: 3,
      image: 'https://i.imgur.com/rkxKX9v.jpeg',
      title: 'Estilo Argentino Gourmet',
      location: 'Marituba - PA',
      description: 'Design inspirado nas parrillas argentinas com grelha regulável em altura'
    },
    {
      id: 4,
      image: 'https://i.imgur.com/AVPRaus.jpeg',
      title: 'Modelo Compacto Premium',
      location: 'Belém - PA',
      description: 'Churrasqueira compacta com sistema rotativo e acabamento em granito'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Projetos que Inspiram
            <span className="block text-orange-500">Cases de Sucesso</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Conheça alguns dos nossos projetos mais marcantes. Cada churrasqueira é única, 
            desenvolvida especialmente para o estilo e necessidades de cada cliente.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 group"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute top-4 right-4 bg-orange-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <ExternalLink size={16} />
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
                  {project.title}
                </h3>
                
                <div className="text-orange-500 text-sm font-medium mb-3">
                  {project.location}
                </div>
                
                <p className="text-gray-600 text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link
            to="/portfolio"
            className="inline-flex items-center bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
          >
            Ver todos os cases
            <ArrowRight className="ml-2" size={20} />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PortfolioPreview;