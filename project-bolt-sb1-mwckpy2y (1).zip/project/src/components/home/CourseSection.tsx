import React from 'react';
import { Flame, Star, Award, Users, BookOpen, Zap } from 'lucide-react';

const CourseSection: React.FC = () => {
  const handleWhatsApp = () => {
    const message = 'Olá! Tenho interesse no Curso Profissional de Churrasco da Personal Grill. Gostaria de mais informações!';
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const courseCards = [
    {
      image: 'https://i.imgur.com/QZCDLMh.jpeg',
      title: 'Técnicas Exclusivas',
      text: 'Descubra segredos que transformam qualquer churrasco em uma experiência gourmet.'
    },
    {
      image: 'https://i.imgur.com/f7iSd1u.jpeg',
      title: 'Aulas Práticas',
      text: 'Aprenda direto na churrasqueira, colocando a mão na massa.'
    },
    {
      image: 'https://i.imgur.com/EHfFiXJ.jpeg',
      title: 'Certificação Profissional',
      text: 'Receba certificado reconhecido e destaque-se como churrasqueiro de elite.'
    },
    {
      image: 'https://i.imgur.com/U02M2xT.jpeg',
      title: 'Mini-Curso Bônus',
      text: 'Na compra de uma churrasqueira Personal Grill, você ganha um mini-curso exclusivo.'
    },
    {
      image: 'https://i.imgur.com/5m6mKN6.jpeg',
      title: 'Estrutura Premium',
      text: 'Aprenda em ambiente profissional com equipamentos de alto nível.'
    },
    {
      image: 'https://i.imgur.com/OgX3Ahy.jpeg',
      title: 'Comunidade Churrasqueira',
      text: 'Faça parte de uma rede de apaixonados por churrasco e troque experiências.'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
      {/* Neon Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-pink-500/5 via-purple-500/5 to-cyan-500/5"></div>
      <div className="absolute top-20 left-20 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-64 h-64 bg-cyan-500/10 rounded-full blur-2xl animate-pulse"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-500/5 rounded-full blur-3xl"></div>
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 relative">
            Curso Profissional de Churrasco
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            "Aprenda técnicas exclusivas com quem é especialista em churrasco premium."
          </p>
          
          {/* Neon Divider */}
          <div className="mt-8 flex justify-center">
            <div className="w-32 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 rounded-full shadow-lg shadow-purple-500/50 animate-pulse"></div>
          </div>
        </div>

        {/* Course Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {courseCards.map((card, index) => (
            <div
              key={index}
              className="bg-black rounded-2xl shadow-lg border border-neon p-4 flex flex-col items-center hover:shadow-neon transition"
            >
              <div className="w-full h-48 flex items-center justify-center bg-black rounded-xl overflow-hidden">
                <img
                  src={card.image}
                  alt={card.title}
                  className="w-full h-full object-contain"
                />
              </div>
              <h3 className="text-xl font-bold text-white mt-4">{card.title}</h3>
              <p className="text-gray-300 text-center mt-2">{card.text}</p>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <div className="text-center">
          <button
            onClick={handleWhatsApp}
            className="relative inline-flex items-center justify-center px-12 py-6 text-xl font-bold text-white bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 rounded-2xl overflow-hidden group hover:scale-105 transition-all duration-300 shadow-2xl"
          >
            {/* Animated Background */}
            <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 animate-pulse"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 via-purple-600 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            
            {/* Neon Glow Effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 rounded-2xl blur opacity-30 group-hover:opacity-60 transition-opacity duration-500 animate-pulse"></div>
            
            {/* Button Content */}
            <span className="relative z-10 flex items-center">
              <Flame className="mr-3 animate-bounce" size={24} />
              👉 Quero aprender agora
              <Flame className="ml-3 animate-bounce" size={24} />
            </span>

            {/* Shine Effect */}
            <div className="absolute inset-0 -top-2 -bottom-2 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
          </button>

          <p className="text-gray-400 text-sm mt-4 animate-pulse">
            ✨ Transforme-se em um mestre churrasqueiro ✨
          </p>
        </div>
    </section>
  );
};

export default CourseSection;