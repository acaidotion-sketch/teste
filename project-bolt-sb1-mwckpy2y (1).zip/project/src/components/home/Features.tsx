import React from 'react';
import { Shield, Cog, Sparkles, Wrench } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: Shield,
      title: 'Estrutura em aço inox 304',
      description: 'Material de alta qualidade para máxima durabilidade e resistência à corrosão, garantindo anos de uso intenso.'
    },
    {
      icon: Cog,
      title: 'Espetos giratórios com motor traseiro',
      description: 'Sistema rotativo automatizado com motor silencioso posicionado na parte traseira para melhor distribuição do calor.'
    },
    {
      icon: Sparkles,
      title: 'Chapas lisas, fácil limpeza',
      description: 'Superfícies lisas e polidas que facilitam a limpeza e manutenção, com sistema automatizado de remoção de resíduos.'
    },
    {
      icon: Wrench,
      title: 'Acabamento sob medida premium',
      description: 'Revestimentos personalizados com materiais nobres: granito, pedra natural, inox escovado e acabamentos exclusivos.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Tecnologia e Qualidade
            <span className="block text-orange-500">em Cada Detalhe</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Cada churrasqueira Personal Grill é desenvolvida com os melhores materiais e tecnologias 
            para garantir performance superior e durabilidade excepcional.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 group"
            >
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <feature.icon className="text-white" size={28} />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-orange-600 transition-colors">
                {feature.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Technical Specs */}
        <div className="mt-16 bg-gradient-to-r from-gray-900 to-black rounded-2xl p-8 md:p-12">
          <div className="text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
              Especificações Técnicas
            </h3>
            <p className="text-gray-300">
              Padrão de qualidade industrial para uso residencial
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-500 mb-2">304</div>
              <div className="text-white font-medium mb-1">Aço Inoxidável</div>
              <div className="text-gray-400 text-sm">Grau alimentício</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-500 mb-2">IP65</div>
              <div className="text-white font-medium mb-1">Proteção</div>
              <div className="text-gray-400 text-sm">Resistente à água</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-500 mb-2">10+</div>
              <div className="text-white font-medium mb-1">Anos</div>
              <div className="text-gray-400 text-sm">Garantia estrutural</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;