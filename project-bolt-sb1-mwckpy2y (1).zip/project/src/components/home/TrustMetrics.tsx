import React from 'react';
import { Calendar, CheckCircle, MapPin, Star } from 'lucide-react';

const TrustMetrics: React.FC = () => {
  const metrics = [
    {
      icon: Calendar,
      value: 'Desde 2018',
      label: 'Anos de experiência',
      description: 'Tradição em churrasqueiras premium'
    },
    {
      icon: CheckCircle,
      value: '500+',
      label: 'Projetos finalizados',
      description: 'Churrasqueiras entregues em Belém'
    },
    {
      icon: MapPin,
      value: 'Belém e região',
      label: 'Área de atendimento',
      description: 'Cobertura completa da região metropolitana'
    },
    {
      icon: Star,
      value: '★★★★★',
      label: 'Avaliação Google',
      description: 'Excelência reconhecida pelos clientes'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Confiança Construída
            <span className="block text-orange-500">Projeto a Projeto</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nossa experiência e dedicação se refletem em cada churrasqueira entregue. 
            Números que comprovam nossa excelência em Belém e região.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {metrics.map((metric, index) => (
            <div
              key={index}
              className="text-center group hover:scale-105 transition-transform duration-300"
            >
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-orange-500/25">
                <metric.icon className="text-white" size={32} />
              </div>
              
              <div className="text-3xl md:text-4xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
                {metric.value}
              </div>
              
              <div className="text-lg font-semibold text-gray-700 mb-2">
                {metric.label}
              </div>
              
              <p className="text-gray-600 text-sm">
                {metric.description}
              </p>
            </div>
          ))}
        </div>

        {/* Testimonial */}
        <div className="mt-16 bg-gray-50 rounded-2xl p-8 md:p-12">
          <div className="text-center">
            <div className="text-orange-500 text-4xl mb-4">"</div>
            <blockquote className="text-xl md:text-2xl text-gray-700 font-medium mb-6 italic">
              A Personal Grill transformou minha área gourmet. O acabamento em granito preto e o sistema rotativo 
              funcionam perfeitamente. O mini-curso foi fundamental para dominar as técnicas!
            </blockquote>
            <div className="flex items-center justify-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">RC</span>
              </div>
              <div className="text-left">
                <div className="font-semibold text-gray-900">Roberto Costa</div>
                <div className="text-gray-600 text-sm">Cliente Personal Grill - Belém</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustMetrics;