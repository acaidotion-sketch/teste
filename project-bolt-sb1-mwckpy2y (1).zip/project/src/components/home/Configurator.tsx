import React, { useState } from 'react';
import { ArrowRight, Flame, Settings, Palette, MapPin, User, Phone, Mail } from 'lucide-react';

const Configurator: React.FC = () => {
  const [formData, setFormData] = useState({
    tipo: '',
    espetos: '',
    grelha: '',
    acabamento: '',
    local: '',
    nome: '',
    telefone: '',
    email: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const whatsappMessage = `Olá! Gostaria de um orçamento personalizado:

🔥 *CONFIGURAÇÃO DA CHURRASQUEIRA*
• Tipo: ${formData.tipo}
• Espetos: ${formData.espetos}
• Grelha: ${formData.grelha}
• Acabamento: ${formData.acabamento}
• Local: ${formData.local}

📞 *CONTATO*
• Nome: ${formData.nome}
• Telefone: ${formData.telefone}
• Email: ${formData.email}

Aguardo retorno!`;

    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, '_blank');
  };

  const isFormValid = Object.values(formData).every(value => value.trim() !== '');

  return (
    <section id="configurator" className="py-20 bg-gradient-to-br from-gray-900 to-black">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Monte sua churrasqueira ideal
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Configure cada detalhe da sua churrasqueira premium e receba um orçamento personalizado
          </p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 md:p-12 shadow-2xl">
          {/* Step 1: Tipo */}
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mr-3">1</div>
              <h3 className="text-xl font-bold text-gray-900 flex items-center">
                <Flame className="mr-2 text-orange-500" size={24} />
                Escolha o tipo
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Alvenaria tradicional', 'Pré-moldada premium'].map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => handleInputChange('tipo', option)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    formData.tipo === option
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <div className="font-semibold">{option}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    {option.includes('Alvenaria') 
                      ? 'Construção tradicional com revestimento personalizado'
                      : 'Estrutura pré-fabricada com instalação rápida'
                    }
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Espetos */}
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mr-3">2</div>
              <h3 className="text-xl font-bold text-gray-900 flex items-center">
                <Settings className="mr-2 text-orange-500" size={24} />
                Sistema de espetos
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {['2 espetos rotativos', '4 espetos rotativos', '6 espetos rotativos'].map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => handleInputChange('espetos', option)}
                  className={`p-4 rounded-lg border-2 transition-all text-center ${
                    formData.espetos === option
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <div className="font-semibold">{option}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 3: Grelha */}
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mr-3">3</div>
              <h3 className="text-xl font-bold text-gray-900">Tipo de grelha</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Grelha Argentina (regulável)', 'Grelha Uruguaia (fixa)'].map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => handleInputChange('grelha', option)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    formData.grelha === option
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <div className="font-semibold">{option}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    {option.includes('Argentina') 
                      ? 'Altura regulável para controle preciso'
                      : 'Posição fixa otimizada para carnes'
                    }
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 4: Acabamento */}
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mr-3">4</div>
              <h3 className="text-xl font-bold text-gray-900 flex items-center">
                <Palette className="mr-2 text-orange-500" size={24} />
                Acabamento premium
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Granito preto absoluto', 'Pedra natural', 'Inox escovado', 'Revestimento personalizado'].map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => handleInputChange('acabamento', option)}
                  className={`p-3 rounded-lg border-2 transition-all text-center ${
                    formData.acabamento === option
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <div className="font-semibold">{option}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 5: Local */}
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold mr-3">5</div>
              <h3 className="text-xl font-bold text-gray-900 flex items-center">
                <MapPin className="mr-2 text-orange-500" size={24} />
                Local de instalação
              </h3>
            </div>
            <input
              type="text"
              placeholder="Ex: Área gourmet coberta, quintal, varanda..."
              value={formData.local}
              onChange={(e) => handleInputChange('local', e.target.value)}
              className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
            />
          </div>

          {/* Contato */}
          <div className="mb-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <User className="mr-2 text-orange-500" size={24} />
              Seus dados para contato
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input
                type="text"
                placeholder="Nome completo"
                value={formData.nome}
                onChange={(e) => handleInputChange('nome', e.target.value)}
                className="p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
              />
              <input
                type="tel"
                placeholder="(91) 99999-9999"
                value={formData.telefone}
                onChange={(e) => handleInputChange('telefone', e.target.value)}
                className="p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
              />
              <input
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={!isFormValid}
            className={`w-full py-4 px-8 rounded-lg font-bold text-lg transition-all duration-300 flex items-center justify-center ${
              isFormValid
                ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Receber orçamento personalizado
            <ArrowRight className="ml-2" size={20} />
          </button>

          <p className="text-center text-gray-600 text-sm mt-4">
            Você será redirecionado para o WhatsApp com sua configuração pronta
          </p>
        </form>
      </div>
    </section>
  );
};

export default Configurator;