import React, { useState, useRef } from 'react';
import { ArrowDown, Flame, Wrench, Award } from 'lucide-react';

const Hero: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const scrollToConfigurator = () => {
    const element = document.getElementById('configurator');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePlayVideo = () => {
    setIsPlaying(true);
  };

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <img
              src="https://i.imgur.com/JSQwSQi.png"
              alt="Personal Grill"
              className="h-20 w-auto mb-6"
            />
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Churrasqueiras
              <span className="block text-orange-500">Premium e</span>
              <span className="block">Sob Medida</span>
              <span className="block text-2xl md:text-3xl text-gray-300 mt-2">em Belém</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-lg">
              Tecnologia, design e <strong className="text-orange-500">mini-curso de churrasco incluso</strong>. 
              Estrutura em aço inox 304 para máxima durabilidade.
            </p>

            {/* Features Pills */}
            <div className="flex flex-wrap gap-3 mb-8">
              <div className="flex items-center bg-gray-800/50 px-4 py-2 rounded-full border border-orange-500/20">
                <Wrench className="text-orange-500 mr-2" size={16} />
                <span className="text-gray-300 text-sm">Aço Inox 304</span>
              </div>
              <div className="flex items-center bg-gray-800/50 px-4 py-2 rounded-full border border-orange-500/20">
                <Award className="text-orange-500 mr-2" size={16} />
                <span className="text-gray-300 text-sm">Mini-curso Incluso</span>
              </div>
              <div className="flex items-center bg-gray-800/50 px-4 py-2 rounded-full border border-orange-500/20">
                <Flame className="text-orange-500 mr-2" size={16} />
                <span className="text-gray-300 text-sm">Sob Medida</span>
              </div>
            </div>

            <button
              onClick={scrollToConfigurator}
              controlsList="nodownload"
              className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105 group"
            >
              Monte a sua churrasqueira
              <ArrowDown className="inline ml-2 group-hover:translate-y-1 transition-transform" size={20} />
            </button>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative w-full aspect-video rounded-2xl overflow-hidden shadow-2xl">
              <video 
                src="https://i.imgur.com/OGAI4qW.mp4" 
                controls 
                autoPlay
                className="w-full aspect-video rounded-2xl shadow-2xl"
              >
                Seu navegador não suporta vídeos HTML5.
              </video>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="text-orange-500" size={24} />
      </div>
    </section>
  );
};

export default Hero;