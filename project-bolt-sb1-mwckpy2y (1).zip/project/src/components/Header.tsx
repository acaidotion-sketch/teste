import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, MessageSquare, Flame } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const handleWhatsApp = () => {
    const message = 'Olá! Gostaria de mais informações sobre as churrasqueiras da Personal Grill.';
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const scrollToConfigurator = () => {
    if (location.pathname === '/') {
      const element = document.getElementById('configurator');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.location.href = '/#configurator';
    }
    setIsMenuOpen(false);
  };

  const menuItems = [
    { label: 'Início', path: '/' },
    { label: 'Serviços', path: '/servicos' },
    { label: 'Monte a sua', action: scrollToConfigurator },
    { label: 'Portfólio', path: '/portfolio' },
    { label: 'Blog', path: '/blog' },
    { label: 'Contato', path: '/contato' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-lg z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <img
              src="https://i.imgur.com/JSQwSQi.png"
              alt="Personal Grill"
              className="h-12 w-auto"
            />
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-8">
            {menuItems.map((item, index) => (
              item.path ? (
                <Link
                  key={index}
                  to={item.path}
                  className={`font-medium transition-colors hover:text-orange-500 ${
                    location.pathname === item.path ? 'text-orange-500' : 'text-gray-700'
                  }`}
                >
                  {item.label}
                </Link>
              ) : (
                <button
                  key={index}
                  onClick={item.action}
                  className="font-medium text-gray-700 hover:text-orange-500 transition-colors"
                >
                  {item.label}
                </button>
              )
            ))}
          </nav>

          {/* WhatsApp Button */}
          <div className="hidden md:flex items-center space-x-4">
            <button
              onClick={handleWhatsApp}
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center shadow-lg hover:shadow-xl"
            >
              <MessageSquare size={18} className="mr-2" />
              (91) 99358-9908
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg text-gray-700 hover:bg-gray-100"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4">
              {menuItems.map((item, index) => (
                item.path ? (
                  <Link
                    key={index}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`font-medium transition-colors hover:text-orange-500 ${
                      location.pathname === item.path ? 'text-orange-500' : 'text-gray-700'
                    }`}
                  >
                    {item.label}
                  </Link>
                ) : (
                  <button
                    key={index}
                    onClick={item.action}
                    className="font-medium text-gray-700 hover:text-orange-500 transition-colors text-left"
                  >
                    {item.label}
                  </button>
                )
              ))}
              <button
                onClick={handleWhatsApp}
                className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center w-fit"
              >
                <MessageSquare size={18} className="mr-2" />
                (91) 99358-9908
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;