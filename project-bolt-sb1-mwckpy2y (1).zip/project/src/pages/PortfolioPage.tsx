import React, { useState } from 'react';
import { Filter, MapPin, Calendar, ArrowRight } from 'lucide-react';

const PortfolioPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('todos');

  const handleWhatsApp = (project?: any) => {
    const message = project 
      ? `Olá! Vi o projeto "${project.title}" no portfólio e gostaria de algo similar. Podem me ajudar?`
      : 'Olá! Gostaria de mais informações sobre os projetos da Personal Grill.';
    
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const projects = [
    {
      id: 1,
      image: 'https://i.imgur.com/nDNKpqC.jpeg',
      title: 'Churrasqueira Premium Inox 304',
      location: 'Belém - PA',
      date: 'Janeiro 2024',
      category: 'premium',
      description: 'Modelo executivo com estrutura em aço inoxidável 304, sistema de tiragem otimizado e acabamento espelhado.',
      specs: ['Aço Inox 304', '4 Espetos Rotativos', 'Granito Preto', 'Sistema Exaustão']
    },
    {
      id: 2,
      image: 'https://i.imgur.com/sYCegxl.jpeg',
      title: 'Churrasqueira Alvenaria Rústica',
      location: 'Ananindeua - PA',
      date: 'Dezembro 2023',
      category: 'alvenaria',
      description: 'Construção em alvenaria com revestimento em pedra natural, forno integrado e sistema de defumação.',
      specs: ['Alvenaria', 'Forno Integrado', 'Pedra Natural', '6 Espetos']
    },
    {
      id: 3,
      image: 'https://i.imgur.com/rkxKX9v.jpeg',
      title: 'Modelo Estilo Argentino',
      location: 'Marituba - PA',
      date: 'Novembro 2023',
      category: 'premium',
      description: 'Design inspirado nas parrillas argentinas com grelha regulável em altura e braseiro amplo.',
      specs: ['Estilo Argentino', 'Grelha Regulável', 'Braseiro Amplo', 'Inox Premium']
    },
    {
      id: 4,
      image: 'https://i.imgur.com/AVPRaus.jpeg',
      title: 'Churrasqueira Compacta Premium',
      location: 'Belém - PA',
      date: 'Outubro 2023',
      category: 'compacta',
      description: 'Modelo compacto sem perder funcionalidade, com sistema rotativo automático.',
      specs: ['Compacta', 'Rotativo Automático', 'Granito Preto', 'Design Moderno']
    },
    {
      id: 5,
      image: 'https://i.imgur.com/jjFdnPk.jpeg',
      title: 'Sistema Duplo Profissional',
      location: 'Belém - PA',
      date: 'Setembro 2023',
      category: 'premium',
      description: 'Churrasqueira com duplo sistema: grelha fixa e espeto rotativo, ideal para grandes eventos.',
      specs: ['Sistema Duplo', 'Uso Profissional', 'Grande Capacidade', 'Inox 304']
    },
    {
      id: 6,
      image: 'https://i.imgur.com/Zwl3F4Q.jpeg',
      title: 'Modelo Português Tradicional',
      location: 'Benevides - PA',
      date: 'Agosto 2023',
      category: 'alvenaria',
      description: 'Inspirada nas churrasqueiras portuguesas com sistema de brasas elevado.',
      specs: ['Estilo Português', 'Ferro Fundido', 'Brasas Elevado', 'Azulejo Tradicional']
    },
    {
      id: 7,
      image: 'https://i.imgur.com/IVXoLu6.jpeg',
      title: 'Churrasqueira Industrial Inox',
      location: 'Belém - PA',
      date: 'Julho 2023',
      category: 'premium',
      description: 'Modelo industrial com estrutura reforçada em inox e sistema de exaustão integrado.',
      specs: ['Industrial', 'Exaustão Integrada', 'Alto Volume', 'Inox Reforçado']
    },
    {
      id: 8,
      image: 'https://i.imgur.com/bfnEtcM.jpeg',
      title: 'Design Moderno Minimalista',
      location: 'Ananindeua - PA',
      date: 'Junho 2023',
      category: 'premium',
      description: 'Churrasqueira com design clean e minimalista, estrutura em concreto aparente.',
      specs: ['Design Minimalista', 'Concreto Aparente', 'Alta Eficiência', 'Sistema Moderno']
    },
    {
      id: 9,
      image: 'https://i.imgur.com/ZpKIK3u.jpeg',
      title: 'Modelo Multi-Grelhas',
      location: 'Belém - PA',
      date: 'Maio 2023',
      category: 'premium',
      description: 'Sistema inovador com múltiplas grelhas em diferentes alturas.',
      specs: ['Multi-Grelhas', 'Alturas Variáveis', 'Cozimento Simultâneo', 'Controle Independente']
    },
    {
      id: 10,
      image: 'https://i.imgur.com/1A8e84w.jpeg',
      title: 'Churrasqueira Portátil Premium',
      location: 'Belém - PA',
      date: 'Abril 2023',
      category: 'compacta',
      description: 'Modelo portátil sem comprometer a qualidade, com rodas industriais.',
      specs: ['Portátil', 'Rodas Industriais', 'Montagem Rápida', 'Qualidade Premium']
    },
    {
      id: 11,
      image: 'https://i.imgur.com/HTZG7Sy.jpeg',
      title: 'Sistema Rotativo Avançado',
      location: 'Marituba - PA',
      date: 'Março 2023',
      category: 'premium',
      description: 'Churrasqueira com sistema rotativo de alta precisão e motor silencioso.',
      specs: ['Rotativo Avançado', 'Motor Silencioso', 'Velocidade Variável', 'Alta Precisão']
    },
    {
      id: 12,
      image: 'https://i.imgur.com/IDtRCtC.jpeg',
      title: 'Modelo Gourmet Executivo',
      location: 'Belém - PA',
      date: 'Fevereiro 2023',
      category: 'premium',
      description: 'Churrasqueira gourmet com acabamento premium e sistema de controle de temperatura.',
      specs: ['Gourmet', 'Controle Temperatura', 'Design Exclusivo', 'Acabamento Premium']
    }
  ];

  const filters = [
    { id: 'todos', label: 'Todos os Projetos', count: projects.length },
    { id: 'premium', label: 'Premium', count: projects.filter(p => p.category === 'premium').length },
    { id: 'alvenaria', label: 'Alvenaria', count: projects.filter(p => p.category === 'alvenaria').length },
    { id: 'compacta', label: 'Compacta', count: projects.filter(p => p.category === 'compacta').length }
  ];

  const filteredProjects = activeFilter === 'todos' 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Portfólio
              <span className="block text-orange-500 text-3xl md:text-4xl mt-2">
                Cases de Sucesso
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Conheça nossos projetos mais marcantes. Cada churrasqueira é única, 
              desenvolvida especialmente para o estilo e necessidades de cada cliente.
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center ${
                  activeFilter === filter.id
                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                    : 'bg-white text-gray-700 hover:bg-orange-50 hover:text-orange-600'
                }`}
              >
                <Filter size={16} className="mr-2" />
                {filter.label} ({filter.count})
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 overflow-hidden group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.category}
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-orange-600 transition-colors">
                    {project.title}
                  </h3>
                  
                  <div className="flex items-center text-gray-600 text-sm mb-2">
                    <MapPin size={14} className="mr-1" />
                    {project.location}
                  </div>
                  
                  <div className="flex items-center text-gray-600 text-sm mb-4">
                    <Calendar size={14} className="mr-1" />
                    {project.date}
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.specs.map((spec, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-orange-100 text-orange-700 text-xs font-medium rounded-full"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                  
                  <button
                    onClick={() => handleWhatsApp(project)}
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 px-6 rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg hover:shadow-xl group/btn"
                  >
                    <span className="flex items-center justify-center">
                      Quero algo similar
                      <ArrowRight size={16} className="ml-2 group-hover/btn:translate-x-1 transition-transform" />
                    </span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Seu Projeto Pode Estar Aqui
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Entre em contato e vamos criar juntos sua churrasqueira dos sonhos
          </p>
          <button
            onClick={() => handleWhatsApp()}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
          >
            Iniciar Meu Projeto: (91) 99358-9908
          </button>
        </div>
      </section>
    </div>
  );
};

export default PortfolioPage;