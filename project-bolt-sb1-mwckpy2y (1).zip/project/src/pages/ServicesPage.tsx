import React from 'react';
import { Flame, Cog, Cuboid as Cube, GraduationCap, Shield, Wrench, Palette, Settings } from 'lucide-react';

const ServicesPage: React.FC = () => {
  const handleWhatsApp = () => {
    const message = 'Olá! Gostaria de mais informações sobre os serviços da Personal Grill.';
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const services = [
    {
      icon: Flame,
      title: 'Churrasqueiras Sob Medida',
      description: 'Desenvolvimento completo de churrasqueiras personalizadas com estrutura em aço inox 304, sistema de tiragem otimizado e acabamentos premium.',
      features: [
        'Estrutura em aço inoxidável 304',
        'Sistema de tiragem otimizado',
        'Dimensões personalizadas',
        'Acabamentos premium disponíveis'
      ],
      image: 'https://images.pexels.com/photos/1105325/pexels-photo-1105325.jpeg'
    },
    {
      icon: Cog,
      title: 'Acessórios Premium',
      description: 'Linha completa de acessórios para churrasqueiras: espetos rotativos, grelhas argentinas/uruguaias, coifas e sistemas de exaustão.',
      features: [
        'Espetos rotativos com motor traseiro',
        'Grelhas Argentina e Uruguaia',
        'Coifas e sistemas de exaustão',
        'Acessórios em aço inox'
      ],
      image: 'https://images.pexels.com/photos/2233729/pexels-photo-2233729.jpeg'
    },
    {
      icon: Cube,
      title: 'Projeto 3D Personalizado',
      description: 'Visualização completa do seu projeto antes da execução com renderização 3D realística e plantas técnicas detalhadas.',
      features: [
        'Modelagem 3D realística',
        'Plantas técnicas detalhadas',
        'Visualização de materiais',
        'Aprovação antes da execução'
      ],
      image: 'https://images.pexels.com/photos/3862132/pexels-photo-3862132.jpeg'
    },
    {
      icon: GraduationCap,
      title: 'Mini-curso de Churrasco',
      description: 'Curso prático incluso com cada churrasqueira, ensinando técnicas profissionais de preparo, controle de temperatura e cortes especiais.',
      features: [
        'Técnicas de controle de fogo',
        'Preparo de diferentes cortes',
        'Controle de temperatura',
        'Dicas de temperos e marinadas'
      ],
      image: 'https://images.pexels.com/photos/1105325/pexels-photo-1105325.jpeg'
    }
  ];

  const technicalSpecs = [
    {
      icon: Shield,
      title: 'Materiais Premium',
      items: ['Aço inoxidável 304 grau alimentício', 'Refratários de alta temperatura', 'Isolamento térmico avançado', 'Acabamentos resistentes']
    },
    {
      icon: Wrench,
      title: 'Sistemas Técnicos',
      items: ['Motor rotativo silencioso', 'Sistema de tiragem otimizado', 'Controle de temperatura', 'Limpeza automatizada']
    },
    {
      icon: Palette,
      title: 'Acabamentos',
      items: ['Granito preto absoluto', 'Pedra natural selecionada', 'Inox escovado premium', 'Revestimentos personalizados']
    },
    {
      icon: Settings,
      title: 'Instalação',
      items: ['Projeto técnico completo', 'Instalação profissional', 'Testes de funcionamento', 'Garantia estrutural 10 anos']
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Serviços Premium
              <span className="block text-orange-500 text-3xl md:text-4xl mt-2">
                Personal Grill
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Soluções completas em churrasqueiras: desde o projeto 3D até o mini-curso de churrasco. 
              Tecnologia, qualidade e experiência em cada detalhe.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nossos Serviços
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Oferecemos soluções completas para sua churrasqueira dos sonhos
            </p>
          </div>

          <div className="space-y-16">
            {services.map((service, index) => (
              <div
                key={index}
                className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-12`}
              >
                <div className="flex-1">
                  <div className="flex items-center mb-6">
                    <div className="bg-gradient-to-r from-orange-500 to-orange-600 w-16 h-16 rounded-xl flex items-center justify-center mr-4">
                      <service.icon className="text-white" size={32} />
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-gray-900">
                      {service.title}
                    </h3>
                  </div>
                  
                  <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                    {service.description}
                  </p>
                  
                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <button
                    onClick={handleWhatsApp}
                    className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-3 rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg hover:shadow-xl"
                  >
                    Solicitar Orçamento
                  </button>
                </div>
                
                <div className="flex-1">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-80 object-cover rounded-2xl shadow-xl"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Especificações Técnicas
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Padrão de qualidade industrial aplicado em projetos residenciais
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {technicalSpecs.map((spec, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="bg-gradient-to-r from-orange-500 to-orange-600 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <spec.icon className="text-white" size={28} />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {spec.title}
                </h3>
                
                <ul className="space-y-2">
                  {spec.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="text-gray-600 text-sm flex items-start">
                      <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mr-2 mt-2 flex-shrink-0"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para Começar seu Projeto?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Entre em contato e receba um orçamento personalizado com projeto 3D incluso
          </p>
          <button
            onClick={handleWhatsApp}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
          >
            Falar no WhatsApp: (91) 99358-9908
          </button>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;