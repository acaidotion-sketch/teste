import React from 'react';
import { Award, Users, Wrench, Heart, Target, Shield } from 'lucide-react';

const AboutPage: React.FC = () => {
  const handleWhatsApp = () => {
    const message = 'Olá! Gostaria de conhecer mais sobre a Personal Grill e seus serviços.';
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const values = [
    {
      icon: Heart,
      title: 'Paixão pelo Churrasco',
      description: 'Cada projeto é desenvolvido com amor e dedicação aos detalhes, porque acreditamos que churrasco é mais que comida, é experiência.'
    },
    {
      icon: Shield,
      title: 'Qualidade Garantida',
      description: 'Utilizamos apenas materiais premium como aço inox 304 e oferecemos garantia estrutural de 10 anos em todos os nossos projetos.'
    },
    {
      icon: Users,
      title: 'Relacionamento Próximo',
      description: 'Mantemos contato direto com cada cliente, desde o projeto até a entrega, garantindo que cada detalhe atenda suas expectativas.'
    },
    {
      icon: Target,
      title: 'Foco na Experiência',
      description: 'Não vendemos apenas churrasqueiras, criamos espaços que aproximam pessoas e fortalecem laços familiares e de amizade.'
    }
  ];

  const team = [
    {
      name: 'Carlos Silva',
      role: 'Fundador & Engenheiro',
      description: 'Especialista em estruturas metálicas com mais de 15 anos de experiência em projetos personalizados.',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg'
    },
    {
      name: 'Ana Rodrigues',
      role: 'Designer de Projetos',
      description: 'Responsável pelos projetos 3D e desenvolvimento visual, garantindo funcionalidade e beleza em cada projeto.',
      image: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg'
    },
    {
      name: 'João Santos',
      role: 'Mestre Churrasqueiro',
      description: 'Especialista em técnicas de churrasco, responsável pelos mini-cursos e consultoria gastronômica.',
      image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Sobre a
              <span className="block text-orange-500 text-3xl md:text-4xl mt-2">
                Personal Grill
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Desde 2018 transformando espaços em pontos de encontro memoráveis, 
              onde cada churrasco se torna uma celebração da vida.
            </p>
          </div>
        </div>
      </section>

      {/* Nossa História */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Nossa História
              </h2>
              <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
                <p>
                  A Personal Grill nasceu da paixão pelo churrasco e da percepção de que as churrasqueiras 
                  disponíveis no mercado não atendiam às necessidades específicas de cada família.
                </p>
                <p>
                  Fundada em 2018 em Belém do Pará, começamos com um objetivo claro: criar churrasqueiras 
                  sob medida que combinassem tecnologia, design e funcionalidade, sempre com materiais 
                  de primeira qualidade.
                </p>
                <p>
                  Hoje, após mais de 500 projetos entregues, continuamos fiéis à nossa missão: 
                  transformar espaços em pontos de encontro memoráveis, onde cada churrasco se torna 
                  uma celebração da vida.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1105325/pexels-photo-1105325.jpeg"
                alt="Churrasqueira Personal Grill"
                className="w-full h-96 object-cover rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-orange-500 text-white p-6 rounded-xl shadow-xl">
                <div className="text-center">
                  <div className="text-3xl font-bold">500+</div>
                  <div className="text-sm">Projetos Entregues</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Nossos Valores */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nossos Valores
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Os princípios que guiam cada projeto e relacionamento que construímos
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                <div className="bg-gradient-to-r from-orange-500 to-orange-600 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <value.icon className="text-white" size={28} />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {value.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Nossa Equipe */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nossa Equipe
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Profissionais especializados unidos pela paixão em criar experiências únicas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div
                key={index}
                className="text-center group hover:scale-105 transition-transform duration-300"
              >
                <div className="relative mb-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-48 h-48 object-cover rounded-full mx-auto shadow-xl group-hover:shadow-2xl transition-shadow"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-orange-500/20 to-transparent rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {member.name}
                </h3>
                
                <div className="text-orange-500 font-medium mb-4">
                  {member.role}
                </div>
                
                <p className="text-gray-600 leading-relaxed">
                  {member.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Diferenciais */}
      <section className="py-20 bg-gradient-to-r from-gray-900 to-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Por que Escolher a Personal Grill?
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Diferenciais que fazem toda a diferença no seu projeto
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-orange-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Award className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Materiais Premium</h3>
              <p className="text-gray-300">
                Aço inox 304 grau alimentício, refratários de alta temperatura e acabamentos nobres
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Wrench className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Projeto 3D Incluso</h3>
              <p className="text-gray-300">
                Visualize sua churrasqueira antes da execução com renderização realística
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Mini-curso Incluso</h3>
              <p className="text-gray-300">
                Aprenda técnicas profissionais de churrasco com nosso especialista
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Vamos Conversar sobre seu Projeto?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Entre em contato e descubra como podemos transformar seu espaço
          </p>
          <button
            onClick={handleWhatsApp}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
          >
            Falar Conosco: (91) 99358-9908
          </button>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;