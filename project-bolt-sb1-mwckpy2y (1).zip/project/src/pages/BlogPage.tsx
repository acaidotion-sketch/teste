import React, { useState } from 'react';
import { Search, Filter, Clock, User, ArrowRight, Flame, Zap, Star } from 'lucide-react';

const BlogPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('galeria');
  const [searchTerm, setSearchTerm] = useState('');

  const churrasqueiras = [
    {
      id: 1,
      image: 'https://i.imgur.com/nDNKpqC.jpeg',
      title: 'Churrasqueira Premium Inox 304',
      description: 'Modelo executivo com estrutura em aço inoxidável 304, sistema de tiragem otimizado e acabamento espelhado. Ideal para áreas gourmet modernas com design sofisticado.',
      specs: ['Aço Inox 304', 'Sistema Rotativo', 'Tiragem Otimizada'],
      category: 'galeria'
    },
    {
      id: 2,
      image: 'https://i.imgur.com/sYCegxl.jpeg',
      title: 'Churrasqueira Alvenaria Rústica',
      description: 'Construção em alvenaria com revestimento em pedra natural, forno integrado e sistema de defumação. Perfeita para espaços tradicionais e ambientes rústicos.',
      specs: ['Alvenaria', 'Forno Integrado', 'Pedra Natural'],
      category: 'galeria'
    },
    {
      id: 3,
      image: 'https://i.imgur.com/rkxKX9v.jpeg',
      title: 'Modelo Estilo Argentino',
      description: 'Design inspirado nas parrillas argentinas com grelha regulável em altura, braseiro amplo e sistema de aquecimento lateral para carnes perfeitas.',
      specs: ['Estilo Argentino', 'Grelha Regulável', 'Braseiro Amplo'],
      category: 'galeria'
    },
    {
      id: 4,
      image: 'https://i.imgur.com/AVPRaus.jpeg',
      title: 'Churrasqueira Compacta Premium',
      description: 'Modelo compacto sem perder funcionalidade, com sistema rotativo automático e acabamento em granito preto absoluto. Ideal para espaços menores.',
      specs: ['Compacta', 'Rotativo Automático', 'Granito Preto'],
      category: 'galeria'
    },
    {
      id: 5,
      image: 'https://i.imgur.com/jjFdnPk.jpeg',
      title: 'Sistema Duplo Profissional',
      description: 'Churrasqueira com duplo sistema: grelha fixa e espeto rotativo, ideal para grandes eventos e uso profissional com alta capacidade de produção.',
      specs: ['Sistema Duplo', 'Uso Profissional', 'Grande Capacidade'],
      category: 'galeria'
    },
    {
      id: 6,
      image: 'https://i.imgur.com/Zwl3F4Q.jpeg',
      title: 'Modelo Português Tradicional',
      description: 'Inspirada nas churrasqueiras portuguesas com sistema de brasas elevado, grelha em ferro fundido e acabamento em azulejo tradicional.',
      specs: ['Estilo Português', 'Ferro Fundido', 'Brasas Elevado'],
      category: 'galeria'
    },
    {
      id: 7,
      image: 'https://i.imgur.com/IVXoLu6.jpeg',
      title: 'Churrasqueira Industrial Inox',
      description: 'Modelo industrial com estrutura reforçada em inox, sistema de exaustão integrado e capacidade para grandes volumes. Perfeita para restaurantes.',
      specs: ['Industrial', 'Exaustão Integrada', 'Alto Volume'],
      category: 'galeria'
    },
    {
      id: 8,
      image: 'https://i.imgur.com/bfnEtcM.jpeg',
      title: 'Design Moderno Minimalista',
      description: 'Churrasqueira com design clean e minimalista, estrutura em concreto aparente e sistema de aquecimento otimizado para máxima eficiência.',
      specs: ['Design Minimalista', 'Concreto Aparente', 'Alta Eficiência'],
      category: 'galeria'
    },
    {
      id: 9,
      image: 'https://i.imgur.com/ZpKIK3u.jpeg',
      title: 'Modelo Multi-Grelhas',
      description: 'Sistema inovador com múltiplas grelhas em diferentes alturas, permitindo cozimento simultâneo de diversos alimentos com controle independente.',
      specs: ['Multi-Grelhas', 'Alturas Variáveis', 'Cozimento Simultâneo'],
      category: 'galeria'
    },
    {
      id: 10,
      image: 'https://i.imgur.com/1A8e84w.jpeg',
      title: 'Churrasqueira Portátil Premium',
      description: 'Modelo portátil sem comprometer a qualidade, com rodas industriais e sistema de montagem rápida. Ideal para eventos externos.',
      specs: ['Portátil', 'Rodas Industriais', 'Montagem Rápida'],
      category: 'galeria'
    },
    {
      id: 11,
      image: 'https://i.imgur.com/HTZG7Sy.jpeg',
      title: 'Sistema Rotativo Avançado',
      description: 'Churrasqueira com sistema rotativo de alta precisão, motor silencioso e controle de velocidade variável para resultados perfeitos.',
      specs: ['Rotativo Avançado', 'Motor Silencioso', 'Velocidade Variável'],
      category: 'galeria'
    },
    {
      id: 12,
      image: 'https://i.imgur.com/IDtRCtC.jpeg',
      title: 'Modelo Gourmet Executivo',
      description: 'Churrasqueira gourmet com acabamento premium, sistema de controle de temperatura e design exclusivo para ambientes sofisticados.',
      specs: ['Gourmet', 'Controle Temperatura', 'Design Exclusivo'],
      category: 'galeria'
    },
    {
      id: 13,
      image: 'https://i.imgur.com/phavolZ.jpeg',
      title: 'Churrasqueira Familiar Grande',
      description: 'Modelo familiar com grande capacidade, sistema de aquecimento uniforme e acabamento em pedra natural. Ideal para grandes reuniões.',
      specs: ['Grande Capacidade', 'Aquecimento Uniforme', 'Uso Familiar'],
      category: 'galeria'
    },
    {
      id: 14,
      image: 'https://i.imgur.com/DJATu87.jpeg',
      title: 'Sistema Híbrido Inovador',
      description: 'Churrasqueira híbrida com sistema a gás e carvão, permitindo versatilidade total no preparo de diferentes tipos de alimentos.',
      specs: ['Sistema Híbrido', 'Gás + Carvão', 'Máxima Versatilidade'],
      category: 'galeria'
    },
    {
      id: 15,
      image: 'https://i.imgur.com/bWN9IDY.jpeg',
      title: 'Modelo Clássico Aprimorado',
      description: 'Churrasqueira clássica com melhorias modernas, sistema de limpeza facilitada e acabamento em materiais nobres para durabilidade máxima.',
      specs: ['Clássico Aprimorado', 'Limpeza Fácil', 'Materiais Nobres'],
      category: 'galeria'
    }
  ];

  const blogPosts = [
    {
      id: 'post1',
      title: 'Como Escolher o Tipo Ideal de Churrasqueira',
      excerpt: 'Guia completo para escolher entre alvenaria, pré-moldada ou inox baseado no seu espaço e necessidades.',
      author: 'Personal Grill',
      date: '15 Jan 2024',
      readTime: '8 min',
      category: 'montagem',
      image: 'https://images.pexels.com/photos/1105325/pexels-photo-1105325.jpeg'
    },
    {
      id: 'post2',
      title: 'Revestimentos Premium: Granito vs Pedra Natural',
      excerpt: 'Comparativo detalhado entre diferentes tipos de revestimento para sua churrasqueira.',
      author: 'Personal Grill',
      date: '12 Jan 2024',
      readTime: '6 min',
      category: 'revestimentos',
      image: 'https://images.pexels.com/photos/2233729/pexels-photo-2233729.jpeg'
    },
    {
      id: 'post3',
      title: 'Manutenção do Sistema Rotativo: Dicas Essenciais',
      excerpt: 'Como manter seu espeto rotativo funcionando perfeitamente por anos.',
      author: 'Personal Grill',
      date: '10 Jan 2024',
      readTime: '5 min',
      category: 'dicas',
      image: 'https://images.pexels.com/photos/1105325/pexels-photo-1105325.jpeg'
    }
  ];

  const filters = [
    { id: 'galeria', label: 'Galeria', count: churrasqueiras.length },
    { id: 'montagem', label: 'Montagem', count: 1 },
    { id: 'revestimentos', label: 'Revestimentos', count: 1 },
    { id: 'dicas', label: 'Dicas de Uso', count: 1 }
  ];

  const filteredContent = () => {
    if (activeFilter === 'galeria') {
      return churrasqueiras.filter(item =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    } else {
      return blogPosts.filter(post =>
        post.category === activeFilter &&
        (post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
  };

  const handleWhatsApp = (churrasqueira?: any) => {
    const message = churrasqueira 
      ? `Olá! Tenho interesse na ${churrasqueira.title}. Gostaria de mais informações e orçamento.`
      : 'Olá! Gostaria de mais informações sobre as churrasqueiras.';
    
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Galeria & Blog
              <span className="block text-orange-500 text-3xl md:text-4xl mt-2">
                Personal Grill
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Conheça nossos projetos exclusivos e aprenda tudo sobre churrasqueiras premium
            </p>
            <div className="flex items-center justify-center space-x-4">
              <Flame className="text-orange-500" size={24} />
              <span className="text-gray-300">Tecnologia • Design • Qualidade</span>
              <Flame className="text-orange-500" size={24} />
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Buscar churrasqueiras ou artigos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-2">
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`px-6 py-3 rounded-lg font-medium transition-all ${
                    activeFilter === filter.id
                      ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                      : 'bg-white text-gray-700 hover:bg-orange-50 hover:text-orange-600'
                  }`}
                >
                  {filter.label} ({filter.count})
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {activeFilter === 'galeria' ? (
            /* Churrasqueiras Gallery */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredContent().map((churrasqueira: any) => (
                <div
                  key={churrasqueira.id}
                  className="group bg-gradient-to-br from-gray-900 to-black rounded-2xl overflow-hidden shadow-2xl hover:shadow-orange-500/20 transition-all duration-500 hover:scale-105"
                >
                  {/* Neon Top Bar */}
                  <div className="h-1 bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 shadow-lg shadow-orange-500/50 animate-pulse"></div>
                  
                  {/* Image */}
                  <div className="relative overflow-hidden">
                    <img
                      src={churrasqueira.image}
                      alt={churrasqueira.title}
                      className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                    
                    {/* Floating Neon Badge */}
                    <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg shadow-orange-500/50 animate-pulse">
                      <Star size={14} className="inline mr-1" />
                      Premium
                    </div>
                  </div>

                  {/* Content with Neon Effects */}
                  <div className="p-6 relative">
                    {/* Neon Glow Background */}
                    <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent rounded-b-2xl"></div>
                    
                    <div className="relative z-10">
                      <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-400 transition-colors">
                        {churrasqueira.title}
                      </h3>
                      
                      <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                        {churrasqueira.description}
                      </p>

                      {/* Neon Specs Tags */}
                      <div className="flex flex-wrap gap-2 mb-6">
                        {churrasqueira.specs.map((spec: string, index: number) => (
                          <span
                            key={index}
                            className="px-3 py-1 bg-gradient-to-r from-orange-500/20 to-orange-600/20 text-orange-400 text-xs font-medium rounded-full border border-orange-500/30 shadow-lg shadow-orange-500/20"
                          >
                            <Zap size={10} className="inline mr-1" />
                            {spec}
                          </span>
                        ))}
                      </div>

                      {/* Neon CTA Button */}
                      <button
                        onClick={() => handleWhatsApp(churrasqueira)}
                        className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 px-6 rounded-lg font-bold hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105 group/btn"
                      >
                        <span className="flex items-center justify-center">
                          Solicitar Orçamento
                          <ArrowRight size={16} className="ml-2 group-hover/btn:translate-x-1 transition-transform" />
                        </span>
                      </button>
                    </div>

                    {/* Bottom Neon Line */}
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-orange-500 to-transparent shadow-lg shadow-orange-500/50"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Blog Posts */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredContent().map((post: any) => (
                <article
                  key={post.id}
                  className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden group"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {post.category}
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-orange-600 transition-colors">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-600 mb-4">
                      {post.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <User size={16} className="mr-1" />
                        {post.author}
                      </div>
                      <div className="flex items-center">
                        <Clock size={16} className="mr-1" />
                        {post.readTime}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">{post.date}</span>
                      <button className="text-orange-500 hover:text-orange-600 font-medium flex items-center">
                        Ler mais
                        <ArrowRight size={16} className="ml-1" />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}

          {filteredContent().length === 0 && (
            <div className="text-center py-16">
              <div className="text-gray-400 mb-4">
                <Search size={48} className="mx-auto" />
              </div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">
                Nenhum resultado encontrado
              </h3>
              <p className="text-gray-500">
                Tente ajustar sua busca ou filtros
              </p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para sua Churrasqueira dos Sonhos?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Entre em contato e receba um projeto personalizado
          </p>
          <button
            onClick={() => handleWhatsApp()}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
          >
            Falar no WhatsApp: (91) 99358-9908
          </button>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;