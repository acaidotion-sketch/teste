import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, MessageSquare, Send } from 'lucide-react';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    email: '',
    assunto: '',
    mensagem: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleWhatsApp = () => {
    const message = 'Olá! Gostaria de mais informações sobre as churrasqueiras da Personal Grill.';
    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const whatsappMessage = `Olá! Entrei em contato através do site:

📝 *DADOS DO CONTATO*
• Nome: ${formData.nome}
• Telefone: ${formData.telefone}
• Email: ${formData.email}
• Assunto: ${formData.assunto}

💬 *MENSAGEM*
${formData.mensagem}

Aguardo retorno!`;

    const whatsappUrl = `https://wa.me/5591993589908?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, '_blank');
  };

  const isFormValid = Object.values(formData).every(value => value.trim() !== '');

  const contactInfo = [
    {
      icon: Phone,
      title: 'Telefone / WhatsApp',
      info: '(91) 99358-9908',
      description: 'Atendimento direto via WhatsApp'
    },
    {
      icon: MapPin,
      title: 'Localização',
      info: 'Belém e Região Metropolitana',
      description: 'Atendemos toda a região de Belém'
    },
    {
      icon: Clock,
      title: 'Horário de Atendimento',
      info: 'Segunda a Sexta: 8h às 18h',
      description: 'Sábados: 8h às 12h'
    },
    {
      icon: Mail,
      title: 'Email',
      info: 'contato@personalgrill.com.br',
      description: 'Resposta em até 24 horas'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Entre em Contato
              <span className="block text-orange-500 text-3xl md:text-4xl mt-2">
                Personal Grill
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Estamos prontos para transformar seu espaço em um ponto de encontro memorável. 
              Entre em contato e vamos conversar sobre seu projeto dos sonhos.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 text-center"
              >
                <div className="bg-gradient-to-r from-orange-500 to-orange-600 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-6">
                  <info.icon className="text-white" size={28} />
                </div>
                
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  {info.title}
                </h3>
                
                <div className="text-orange-600 font-semibold mb-2">
                  {info.info}
                </div>
                
                <p className="text-gray-600 text-sm">
                  {info.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & WhatsApp */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* WhatsApp Direct */}
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-8 text-white">
              <div className="text-center mb-8">
                <MessageSquare className="mx-auto mb-4" size={48} />
                <h2 className="text-2xl md:text-3xl font-bold mb-4">
                  Fale Conosco no WhatsApp
                </h2>
                <p className="text-green-100 text-lg">
                  Atendimento rápido e personalizado para seu projeto
                </p>
              </div>

              <div className="space-y-6 mb-8">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-300 rounded-full mr-4"></div>
                  <span>Resposta imediata durante horário comercial</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-300 rounded-full mr-4"></div>
                  <span>Orçamento personalizado sem compromisso</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-300 rounded-full mr-4"></div>
                  <span>Projeto 3D incluso na consulta</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-300 rounded-full mr-4"></div>
                  <span>Atendimento especializado</span>
                </div>
              </div>

              <button
                onClick={handleWhatsApp}
                className="w-full bg-white text-green-600 py-4 px-8 rounded-lg font-bold text-lg hover:bg-green-50 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
              >
                Iniciar Conversa: (91) 99358-9908
              </button>
            </div>

            {/* Contact Form */}
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                Ou Envie uma Mensagem
              </h2>
              <p className="text-gray-600 mb-8">
                Preencha o formulário abaixo e entraremos em contato em breve
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <input
                    type="text"
                    placeholder="Nome completo"
                    value={formData.nome}
                    onChange={(e) => handleInputChange('nome', e.target.value)}
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
                    required
                  />
                  <input
                    type="tel"
                    placeholder="(91) 99999-9999"
                    value={formData.telefone}
                    onChange={(e) => handleInputChange('telefone', e.target.value)}
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
                    required
                  />
                </div>

                <input
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
                  required
                />

                <select
                  value={formData.assunto}
                  onChange={(e) => handleInputChange('assunto', e.target.value)}
                  className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors"
                  required
                >
                  <option value="">Selecione o assunto</option>
                  <option value="Orçamento Churrasqueira">Orçamento Churrasqueira</option>
                  <option value="Projeto 3D">Projeto 3D</option>
                  <option value="Mini-curso">Mini-curso de Churrasco</option>
                  <option value="Manutenção">Manutenção</option>
                  <option value="Outros">Outros</option>
                </select>

                <textarea
                  placeholder="Conte-nos sobre seu projeto ou dúvida..."
                  value={formData.mensagem}
                  onChange={(e) => handleInputChange('mensagem', e.target.value)}
                  rows={5}
                  className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-orange-500 focus:outline-none transition-colors resize-none"
                  required
                ></textarea>

                <button
                  type="submit"
                  disabled={!isFormValid}
                  className={`w-full py-4 px-8 rounded-lg font-bold text-lg transition-all duration-300 flex items-center justify-center ${
                    isFormValid
                      ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Enviar Mensagem
                  <Send className="ml-2" size={20} />
                </button>

                <p className="text-center text-gray-600 text-sm">
                  Você será redirecionado para o WhatsApp com sua mensagem pronta
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nossa Área de Atendimento
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Atendemos Belém e toda a região metropolitana com excelência e pontualidade
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="bg-orange-500 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin size={28} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Belém</h3>
                <p className="text-gray-600">Centro, bairros e região metropolitana</p>
              </div>
              
              <div>
                <div className="bg-orange-500 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin size={28} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Ananindeua</h3>
                <p className="text-gray-600">Todos os bairros e condomínios</p>
              </div>
              
              <div>
                <div className="bg-orange-500 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin size={28} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Região</h3>
                <p className="text-gray-600">Marituba, Benevides e adjacências</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para Começar?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Entre em contato agora e transforme seu espaço em um ponto de encontro memorável
          </p>
          <button
            onClick={handleWhatsApp}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
          >
            Falar no WhatsApp: (91) 99358-9908
          </button>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;