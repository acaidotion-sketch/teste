import React from 'react';
import Hero from '../components/home/Hero';
import Configurator from '../components/home/Configurator';
import Features from '../components/home/Features';
import CourseSection from '../components/home/CourseSection';
import TrustMetrics from '../components/home/TrustMetrics';
import PortfolioPreview from '../components/home/PortfolioPreview';
import Manifesto from '../components/home/Manifesto';

const HomePage: React.FC = () => {
  return (
    <div className="pt-16">
      <Hero />
      <Features />
      <CourseSection />
      <TrustMetrics />
      <Configurator />
      <PortfolioPreview />
      <Manifesto />
    </div>
  );
};

export default HomePage;